# IntelliTicks WordPress Integration

# Installation

1. Contact sales@intelliticks.com to get your account set-up and get the script.
2. Add this plugin to WordPress and enable it. See [Managing Plugins](https://codex.wordpress.org/Managing_Plugins)
4. Visit IntelliTicks Settings on your WordPress site and paste the script from 1st step into the text-area. Click on Save button.

